This code appears to have some problems. In particular the output format does not
follow the same format as other algorithms. Besides during integration, I may have introduced some bug.

Thus, for the time being, the code remains in this package but it is not officially announced as being part of SPMF. 